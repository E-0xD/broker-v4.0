

<html
    class="wf-signikanegative-n3-active wf-signikanegative-n6-active wf-signikanegative-n5-active wf-signikanegative-n7-active wf-signikanegative-n4-active wf-active">

<head>
    <meta name="csrf-token" content="cDAwtQW5CXdTrNRlqHgF4Wgngh4poKsdYm9riwBG">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <meta name="next-head-count" content="2" />
    <link data-next-font="" rel="preconnect" href="/" crossorigin="anonymous" />
    <link rel="preload" href="assets/css/custom.css" as="style" />
    <link rel="stylesheet" href="assets/css/custom.css" data-n-g="" />
    <link rel="preload" href="assets/css/7e73653276d97473.css" as="style" />
    <link rel="stylesheet" href="assets/css/css/7e73653276d97473.css" data-n-g="" />
    <noscript data-n-css=""></noscript>
    <style data-styled="active" data-styled-version="5.3.10"></style>
    <title>Traderxnest| User Login</title>
    <meta charset="utf-8" data-react-helmet="true" />
    <link type="image/x-icon" rel="icon" href="assets/img/logo.png" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Signika+Negative:300,400,500,600,700%7CSignika+Negative:300,400,500,600,700"
        media="all" />
    <link rel="apple-touch-icon" href="assets/img/logo.png" />
    <script id="google-recaptcha-v3"
        src="https://www.google.com/recaptcha/api.js?render=6Ldfr2keAAAAALr9Saitx-TvssAIqWnjBUNRA2gi" async=""></script>
</head>


<body data-new-gr-c-s-check-loaded="14.1155.0" data-gr-ext-installed="" style="font-family: 'Signika Negative'">
    <div id="__next">
        <div>
            <div class="App">
                <div class="sc-bgqQcB sc-gTRrQi fsFCev gXrGIv undefined">
                    <div class="Toastify"></div>
                </div>
                <div class="sc-grzvtn hhNJNb undefined">
                    <div class="content-container">
                        <div class="sc-jNkFXo bDkkho">
                            <a href=""><img src="assets/img/logo.png" alt="Logo"
                                    class="sc-iBTzgk fQiUan" style="height:70px;" /></a>
                        </div>
                        <div id="crm-signup-form" class="ModuleContainer-module_moduleContainer__qkbiY">
                            <form class="FormContainer-module_formContainer__Rdciy" method="POST" action="">
                                
                                                              
                                <h2 class="FormContainer-module_title__hsoF5">Sign in</h2>
                                <div class="Input-module_container__zLqel">
                                    <div class="Input-module_inputWrapper__FIVsA">
                                        <input name="email" class="Input-module_input__WjT81" type="email"
                                            placeholder="Email Address" id="email" autocomplete="email" value=""
                                            required /><span class="Input-module_label__-OEBL">Email Address</span>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <div class="Input-module_inputWrapper__FIVsA">
                                        <input name="password" class="Input-module_input__WjT81" type="password"
                                            placeholder="Password" id="password" autocomplete="password" value=""
                                            required /><span class="Input-module_label__-OEBL">Password</span>
                                    </div>
                                </div>
                                                                <button type="submit" name="submit"
                                    class="Button-module_submitButton__bylzj Button-module_C01__yAEYc">
                                    Sign in
                                </button>
                              
                            </form>
                            
                            <div class="Footer-module_footerLinks__ciyvi Footer-module_light__pUuCo">
                                <a href="register.php">Register Now</a><a href="reset.php">Forgot
                                    Password?</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>