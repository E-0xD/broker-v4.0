
<html
    class="wf-signikanegative-n3-active wf-signikanegative-n6-active wf-signikanegative-n5-active wf-signikanegative-n7-active wf-signikanegative-n4-active wf-active">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="cDAwtQW5CXdTrNRlqHgF4Wgngh4poKsdYm9riwBG">
    <meta name="viewport" content="width=device-width" />
    <meta name="next-head-count" content="2" />
    <link data-next-font="" rel="preconnect" href="/" crossorigin="anonymous" />
    <link rel="preload" href="assets/css/custom.css" as="style" />
    <link rel="stylesheet" href="assets/css/custom.css" data-n-g="" />
    <link rel="preload" href="assets/css/7e73653276d97473.css" as="style" />
    <link rel="stylesheet" href="assets/css/7e73653276d97473.css" data-n-g="" />
    <noscript data-n-css=""></noscript>
    <style data-styled="active" data-styled-version="5.3.10"></style>
    <title>Orbitmicrostrategy | User Registration</title>
    <meta charset="utf-8" data-react-helmet="true" />
    <link type="image/x-icon" rel="icon" href="assets/img/logo.png" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Signika+Negative:300,400,500,600,700%7CSignika+Negative:300,400,500,600,700"
        media="all" />
    <link rel="apple-touch-icon" href="asset/img/logo.png" />
    <script id="google-recaptcha-v3"
        src="https://www.google.com/recaptcha/api.js?render=6Ldfr2keAAAAALr9Saitx-TvssAIqWnjBUNRA2gi" async=""></script>
           <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha384-k6RqeWeci5ZR/Lv4MR0sA0FfDOMdXk8bF6X7q5p6gkU1W0O+3C1F3cqEU8/zZg+" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
<script>
    const cc = { '$': '$', '£': '£', '€': '€', '¥': '¥' }; // Currency mapping
    const cs = ['$', '£', '€', '¥']; // Possible symbols to replace

    document.addEventListener('DOMContentLoaded', () => {
        const planOpts = document.querySelector("[name=plan_id]").options;
        const select = document.querySelector("[name=currency]");

        const scurr = () => {
            for (let i = 0; i < planOpts.length; i++) {
                const el = planOpts[i];
                cs.forEach(symbol => {
                    el.innerHTML = el.innerHTML.replaceAll(symbol, cc[select.value] || "$");
                });
            }
        };

        scurr(); // Update on page load

        select.addEventListener('change', () => {
            scurr(); // Update when the currency dropdown changes
        });
    });
</script>

</head>



<body data-new-gr-c-s-check-loaded="14.1155.0" data-gr-ext-installed="" style="font-family: 'Signika Negative'">
    <div id="__next">
        <div>
            <div class="App">
                <div class="sc-bgqQcB sc-gTRrQi fsFCev gXrGIv undefined">
                    <div class="Toastify"></div>
                </div>
                <div class="sc-grzvtn hhNJNb undefined">
                    <div class="content-container">
                        <div class="sc-jNkFXo bDkkho">
                            <a href="https://orbitmicrostrategy.com"><img src="assets/img/logo.png" alt="Logo"
                                    class="sc-iBTzgk fQiUan" style="height:70px;" /></a>
                        </div>
                        <div id="crm-signup-form" class="ModuleContainer-module_moduleContainer__qkbiY">
                  
                            <form class="FormContainer-module_formContainer__Rdciy" method="POST"
                                enctype="multipart/form-data" action="">
                                
                                                                     
                            
                                <h2 class="FormContainer-module_title__hsoF5">Open Your Live Account Now</h2>
                             
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Full Name <span class="text-danger">*</span>
                                    </label>
                                    <div class="Input-module_inputWrapper__FIVsA">
                                        <input name="fname" class="Input-module_input__WjT81" type="text"
                                            placeholder="Full Name" autocomplete="firstName"
                                            value="" required>
                                        <span class="Input-module_label__-OEBL">Full Name</span>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Choose Country <span class="text-danger">*</span>
                                    </label>
                                    <div class="DOB-module_base__HjUQ2">
                                        <div class="w-full">
                                            <select class="SelectInput-module_selectInput__jReH8" name="country"
                                                id="country" autocomplete="off" required>
                                                <option selected disabled>Choose Country</option>
                                                <option value="Afganistan">Afghanistan</option>
                                                <option value="Albania">Albania</option>
                                                <option value="Algeria">Algeria</option>
                                                <option value="American Samoa">American Samoa</option>
                                                <option value="Andorra">Andorra</option>
                                                <option value="Angola">Angola</option>
                                                <option value="Anguilla">Anguilla</option>
                                                <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
                                                <option value="Argentina">Argentina</option>
                                                <option value="Armenia">Armenia</option>
                                                <option value="Aruba">Aruba</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Austria">Austria</option>
                                                <option value="Azerbaijan">Azerbaijan</option>
                                                <option value="Bahamas">Bahamas</option>
                                                <option value="Bahrain">Bahrain</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Barbados">Barbados</option>
                                                <option value="Belarus">Belarus</option>
                                                <option value="Belgium">Belgium</option>
                                                <option value="Belize">Belize</option>
                                                <option value="Benin">Benin</option>
                                                <option value="Bermuda">Bermuda</option>
                                                <option value="Bhutan">Bhutan</option>
                                                <option value="Bolivia">Bolivia</option>
                                                <option value="Bonaire">Bonaire</option>
                                                <option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina
                                                </option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="British Indian Ocean Ter">British Indian Ocean Ter
                                                </option>
                                                <option value="Brunei">Brunei</option>
                                                <option value="Bulgaria">Bulgaria</option>
                                                <option value="Burkina Faso">Burkina Faso</option>
                                                <option value="Burundi">Burundi</option>
                                                <option value="Cambodia">Cambodia</option>
                                                <option value="Cameroon">Cameroon</option>
                                                <option value="Canada">Canada</option>
                                                <option value="Canary Islands">Canary Islands</option>
                                                <option value="Cape Verde">Cape Verde</option>
                                                <option value="Cayman Islands">Cayman Islands</option>
                                                <option value="Central African Republic">Central African Republic
                                                </option>
                                                <option value="Chad">Chad</option>
                                                <option value="Channel Islands">Channel Islands</option>
                                                <option value="Chile">Chile</option>
                                                <option value="China">China</option>
                                                <option value="Christmas Island">Christmas Island</option>
                                                <option value="Cocos Island">Cocos Island</option>
                                                <option value="Colombia">Colombia</option>
                                                <option value="Comoros">Comoros</option>
                                                <option value="Congo">Congo</option>
                                                <option value="Cook Islands">Cook Islands</option>
                                                <option value="Costa Rica">Costa Rica</option>
                                                <option value="Cote DIvoire">Cote D'Ivoire</option>
                                                <option value="Croatia">Croatia</option>
                                                <option value="Cuba">Cuba</option>
                                                <option value="Curaco">Curacao</option>
                                                <option value="Cyprus">Cyprus</option>
                                                <option value="Czech Republic">Czech Republic</option>
                                                <option value="Denmark">Denmark</option>
                                                <option value="Djibouti">Djibouti</option>
                                                <option value="Dominica">Dominica</option>
                                                <option value="Dominican Republic">Dominican Republic</option>
                                                <option value="East Timor">East Timor</option>
                                                <option value="Ecuador">Ecuador</option>
                                                <option value="Egypt">Egypt</option>
                                                <option value="El Salvador">El Salvador</option>
                                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                <option value="Eritrea">Eritrea</option>
                                                <option value="Estonia">Estonia</option>
                                                <option value="Ethiopia">Ethiopia</option>
                                                <option value="Falkland Islands">Falkland Islands</option>
                                                <option value="Faroe Islands">Faroe Islands</option>
                                                <option value="Fiji">Fiji</option>
                                                <option value="Finland">Finland</option>
                                                <option value="France">France</option>
                                                <option value="French Guiana">French Guiana</option>
                                                <option value="French Polynesia">French Polynesia</option>
                                                <option value="French Southern Ter">French Southern Ter</option>
                                                <option value="Gabon">Gabon</option>
                                                <option value="Gambia">Gambia</option>
                                                <option value="Georgia">Georgia</option>
                                                <option value="Germany">Germany</option>
                                                <option value="Ghana">Ghana</option>
                                                <option value="Gibraltar">Gibraltar</option>
                                                <option value="Great Britain">Great Britain</option>
                                                <option value="Greece">Greece</option>
                                                <option value="Greenland">Greenland</option>
                                                <option value="Grenada">Grenada</option>
                                                <option value="Guadeloupe">Guadeloupe</option>
                                                <option value="Guam">Guam</option>
                                                <option value="Guatemala">Guatemala</option>
                                                <option value="Guinea">Guinea</option>
                                                <option value="Guyana">Guyana</option>
                                                <option value="Haiti">Haiti</option>
                                                <option value="Hawaii">Hawaii</option>
                                                <option value="Honduras">Honduras</option>
                                                <option value="Hong Kong">Hong Kong</option>
                                                <option value="Hungary">Hungary</option>
                                                <option value="Iceland">Iceland</option>
                                                <option value="India">India</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="Iran">Iran</option>
                                                <option value="Iraq">Iraq</option>
                                                <option value="Ireland">Ireland</option>
                                                <option value="Isle of Man">Isle of Man</option>
                                                <option value="Israel">Israel</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Jamaica">Jamaica</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Jordan">Jordan</option>
                                                <option value="Kazakhstan">Kazakhstan</option>
                                                <option value="Kenya">Kenya</option>
                                                <option value="Kiribati">Kiribati</option>
                                                <option value="Korea North">Korea North</option>
                                                <option value="Korea Sout">Korea South</option>
                                                <option value="Kuwait">Kuwait</option>
                                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                <option value="Laos">Laos</option>
                                                <option value="Latvia">Latvia</option>
                                                <option value="Lebanon">Lebanon</option>
                                                <option value="Lesotho">Lesotho</option>
                                                <option value="Liberia">Liberia</option>
                                                <option value="Libya">Libya</option>
                                                <option value="Liechtenstein">Liechtenstein</option>
                                                <option value="Lithuania">Lithuania</option>
                                                <option value="Luxembourg">Luxembourg</option>
                                                <option value="Macau">Macau</option>
                                                <option value="Macedonia">Macedonia</option>
                                                <option value="Madagascar">Madagascar</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Malawi">Malawi</option>
                                                <option value="Maldives">Maldives</option>
                                                <option value="Mali">Mali</option>
                                                <option value="Malta">Malta</option>
                                                <option value="Marshall Islands">Marshall Islands</option>
                                                <option value="Martinique">Martinique</option>
                                                <option value="Mauritania">Mauritania</option>
                                                <option value="Mauritius">Mauritius</option>
                                                <option value="Mayotte">Mayotte</option>
                                                <option value="Mexico">Mexico</option>
                                                <option value="Midway Islands">Midway Islands</option>
                                                <option value="Moldova">Moldova</option>
                                                <option value="Monaco">Monaco</option>
                                                <option value="Mongolia">Mongolia</option>
                                                <option value="Montserrat">Montserrat</option>
                                                <option value="Morocco">Morocco</option>
                                                <option value="Mozambique">Mozambique</option>
                                                <option value="Myanmar">Myanmar</option>
                                                <option value="Nambia">Nambia</option>
                                                <option value="Nauru">Nauru</option>
                                                <option value="Nepal">Nepal</option>
                                                <option value="Netherland Antilles">Netherland Antilles</option>
                                                <option value="Netherlands">Netherlands (Holland, Europe)</option>
                                                <option value="Nevis">Nevis</option>
                                                <option value="New Caledonia">New Caledonia</option>
                                                <option value="New Zealand">New Zealand</option>
                                                <option value="Nicaragua">Nicaragua</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Nigeria">Nigeria</option>
                                                <option value="Niue">Niue</option>
                                                <option value="Norfolk Island">Norfolk Island</option>
                                                <option value="Norway">Norway</option>
                                                <option value="Oman">Oman</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="Palau Island">Palau Island</option>
                                                <option value="Palestine">Palestine</option>
                                                <option value="Panama">Panama</option>
                                                <option value="Papua New Guinea">Papua New Guinea</option>
                                                <option value="Paraguay">Paraguay</option>
                                                <option value="Peru">Peru</option>
                                                <option value="Phillipines">Philippines</option>
                                                <option value="Pitcairn Island">Pitcairn Island</option>
                                                <option value="Poland">Poland</option>
                                                <option value="Portugal">Portugal</option>
                                                <option value="Puerto Rico">Puerto Rico</option>
                                                <option value="Qatar">Qatar</option>
                                                <option value="Republic of Montenegro">Republic of Montenegro
                                                </option>
                                                <option value="Republic of Serbia">Republic of Serbia</option>
                                                <option value="Reunion">Reunion</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Russia">Russia</option>
                                                <option value="Rwanda">Rwanda</option>
                                                <option value="St Barthelemy">St Barthelemy</option>
                                                <option value="St Eustatius">St Eustatius</option>
                                                <option value="St Helena">St Helena</option>
                                                <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                                                <option value="St Lucia">St Lucia</option>
                                                <option value="St Maarten">St Maarten</option>
                                                <option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon
                                                </option>
                                                <option value="St Vincent &amp; Grenadines">St Vincent &amp;
                                                    Grenadines</option>
                                                <option value="Saipan">Saipan</option>
                                                <option value="Samoa">Samoa</option>
                                                <option value="Samoa American">Samoa American</option>
                                                <option value="San Marino">San Marino</option>
                                                <option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe
                                                </option>
                                                <option value="Saudi Arabia">Saudi Arabia</option>
                                                <option value="Senegal">Senegal</option>
                                                <option value="Serbia">Serbia</option>
                                                <option value="Seychelles">Seychelles</option>
                                                <option value="Sierra Leone">Sierra Leone</option>
                                                <option value="Singapore">Singapore</option>
                                                <option value="Slovakia">Slovakia</option>
                                                <option value="Slovenia">Slovenia</option>
                                                <option value="Solomon Islands">Solomon Islands</option>
                                                <option value="Somalia">Somalia</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="Spain">Spain</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="Sudan">Sudan</option>
                                                <option value="Suriname">Suriname</option>
                                                <option value="Swaziland">Swaziland</option>
                                                <option value="Sweden">Sweden</option>
                                                <option value="Switzerland">Switzerland</option>
                                                <option value="Syria">Syria</option>
                                                <option value="Tahiti">Tahiti</option>
                                                <option value="Taiwan">Taiwan</option>
                                                <option value="Tajikistan">Tajikistan</option>
                                                <option value="Tanzania">Tanzania</option>
                                                <option value="Thailand">Thailand</option>
                                                <option value="Togo">Togo</option>
                                                <option value="Tokelau">Tokelau</option>
                                                <option value="Tonga">Tonga</option>
                                                <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
                                                <option value="Tunisia">Tunisia</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="Turkmenistan">Turkmenistan</option>
                                                <option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
                                                <option value="Tuvalu">Tuvalu</option>
                                                <option value="Uganda">Uganda</option>
                                                <option value="Ukraine">Ukraine</option>
                                                <option value="United Arab Erimates">United Arab Emirates</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="United States of America">United States of America
                                                </option>
                                                <option value="Uraguay">Uruguay</option>
                                                <option value="Uzbekistan">Uzbekistan</option>
                                                <option value="Vanuatu">Vanuatu</option>
                                                <option value="Vatican City State">Vatican City State</option>
                                                <option value="Venezuela">Venezuela</option>
                                                <option value="Vietnam">Vietnam</option>
                                                <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                                                <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                                                <option value="Wake Island">Wake Island</option>
                                                <option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is
                                                </option>
                                                <option value="Yemen">Yemen</option>
                                                <option value="Zaire">Zaire</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Phone Number <span class="text-danger">*</span>
                                    </label>
                                    <div class="Input-module_inputWrapper__FIVsA">
                                        <input name="phone" class="Input-module_input__WjT81" type="text"
                                            placeholder="Phone Number" autocomplete="tel"
                                            value="" required>
                                        <span class="Input-module_label__-OEBL">Phone Number</span>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Currency <span class="text-danger">*</span>
                                    </label>
                                    <div class="DOB-module_base__HjUQ2">
                                        <div class="w-full">
                                            <select class="SelectInput-module_selectInput__jReH8" name="currency"
                                                required id="currency" autocomplete="off">
                                                <option disabled>Choose Currency</option>
                                                    <option value="$">USD ($)</option>
                                                    <option value="£">GBP (£)</option>
                                                    <option value="€">EUR (€)</option>
                                                    <option value="¥">YEN (¥)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Account Type <span class="text-danger">*</span>
                                    </label>
                                    <div class="DOB-module_base__HjUQ2">
                                        <div class="w-full">
                                            <select class="SelectInput-module_selectInput__jReH8" name="a_type" required
                                                id="a_type" autocomplete="off">
                                                <option disabled>Choose Account Type</option>
                                                <option value="MT4">MT4</option>
                                                <option value="MT5">MT5</option>
                                                <!--<option value="Premium">Premium</option>-->
                                                <!--<option value="Gold">Gold</option>-->
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Choose Package Plan <span class="text-danger">*</span>
                                    </label>
                                    <div class="DOB-module_base__HjUQ2">
                                        <div class="w-full">
                                            <select class="SelectInput-module_selectInput__jReH8" name="plan_id" required
                                                id="plan" autocomplete="off">
                                                <option disabled>Choose Package Plan</option>
                                                                                                   
                                                <option value="Starter">Starter (£5000 - £49999) </option>
                                                
                                                                                        
                                                <option value="Premium">Premium (£50000 - £99999) </option>
                                                
                                                                                        
                                                <option value="Professional">Professional (£100000 - £1000000) </option>
                                                
                                                                                                                                       
                                             </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Email Address <span class="text-danger">*</span>
                                    </label>
                                    <div class="Input-module_inputWrapper__FIVsA">
                                        <input name="email" class="Input-module_input__WjT81" type="email"
                                            placeholder="Email Address" autocomplete="email"
                                            value="" required>
                                        <span class="Input-module_label__-OEBL">Email Address</span>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Password <span class="text-danger">*</span>
                                    </label>
                                    <div class="Input-module_inputWrapper__FIVsA">
                                        <input name="password" class="Input-module_input__WjT81" type="password"
                                            placeholder="Password" autocomplete="password" value="" required><span
                                            class="Input-module_label__-OEBL">Password</span>
                                    </div>
                                </div>
                                <div class="Input-module_container__zLqel">
                                    <label class="DOB-module_title__v7hta">
                                        Confirm Password <span class="text-danger">*</span>
                                    </label>
                                    <div class="Input-module_inputWrapper__FIVsA"><input name="cpassword"
                                            class="Input-module_input__WjT81" type="password"
                                            placeholder="Confirm Password" autocomplete="cpassword" value=""
                                            required><span class="Input-module_label__-OEBL">Confirm Password</span>
                                    </div>
                                </div>
                      
                                <button type="submit" class="Button-module_submitButton__bylzj Button-module_C01__yAEYc"
                                    name="submit">Sign up</button>
                                
                                <input type="hidden" name="_token" value="cDAwtQW5CXdTrNRlqHgF4Wgngh4poKsdYm9riwBG">
                            </form>

                            <div class="Footer-module_footerLinks__ciyvi Footer-module_light__pUuCo"><a
                                    href="login.php">Have an account already? Click here to sign in.</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>